const {
  makeWASocket,
  useMultiFileAuthState,
  DisconnectReason,
} = require("baileys");
const qrcode = require("qrcode-terminal");
const path = require("path");
const express = require("express");
const fs = require("fs");

const logger = require("./lib/logger");
const { handleAuto } = require("./lib/bot");
const { vipRules } = require("./lib/vip_rules");

// ====== Konstanta Utama ======
const AUTH_DIR = path.resolve(__dirname, "auth2");
const OWNER_JID = "6281462328581@s.whatsapp.net";
const TARGET_JID = "120363164235959904@g.us";
const TARGET_JID_VIP = "120363421197092051@g.us";
const HYDRO_JID = "6287780010053@s.whatsapp.net";
const OWNER_LID = "73521501876361@lid";
const TARGET_NEW = "120363403815460564@g.us";

let sock;
let qrShown = false;

// ====== Fungsi Utama Koneksi ======
async function connect() {
  const { state, saveCreds } = await useMultiFileAuthState(AUTH_DIR);

  sock = makeWASocket({
    auth: state,
    printQRInTerminal: false,
  });

  // Simpan perubahan creds
  sock.ev.on("creds.update", saveCreds);

  // ====== Event: Update Koneksi ======
  sock.ev.on("connection.update", ({ connection, lastDisconnect, qr }) => {
    // QR Code
    if (qr && !qrShown) {
      qrShown = true;
      console.log("Scan QR di bawah ini:");
      qrcode.generate(qr, { small: true });
    }

    // Handle koneksi close / open
    if (connection === "close") {
      const reason = lastDisconnect?.error?.output?.statusCode;
      const reconnect = reason !== DisconnectReason.loggedOut;
      console.log("Koneksi tertutup karena:", reason);
      logger.error("Koneksi tertutup. Reconnect =", reconnect);
      if (reconnect) connect();
    } else if (connection === "open") {
      logger.info("Bot WhatsApp sudah terhubung ✅");
    }
  });

  // ====== Event: Pesan Masuk ======
  sock.ev.on("messages.upsert", async ({ messages }) => {
    const msg = messages[0];
    if (!msg || msg.key?.fromMe) return;
    const from = msg.key.remoteJid;
    const isAuthor = msg.key.participant === OWNER_LID;

    // Ambil isi pesan (fallback banyak tipe message)
    const body = (
      msg.message?.conversation ||
      msg.message?.extendedTextMessage?.text ||
      msg.message?.imageMessage?.caption ||
      msg.message?.videoMessage?.caption ||
      msg.message?.audioMessage?.caption ||
      msg.message?.documentMessage?.caption ||
      msg.message?.documentWithCaptionMessage?.message?.documentMessage
        ?.caption ||
      msg.message?.stickerMessage?.caption ||
      msg.message?.locationMessage?.name ||
      msg.message?.contactMessage?.displayName ||
      msg.message?.contactsArrayMessage?.contacts?.[0]?.displayName ||
      msg.message?.extendedTextMessage?.contextInfo?.quotedMessage
        ?.conversation ||
      msg.message?.extendedTextMessage?.contextInfo?.quotedMessage
        ?.extendedTextMessage?.text ||
      msg.message?.extendedTextMessage?.contextInfo?.quotedMessage?.imageMessage
        ?.caption ||
      msg.message?.extendedTextMessage?.contextInfo?.quotedMessage?.videoMessage
        ?.caption ||
      msg.message?.extendedTextMessage?.contextInfo?.quotedMessage
        ?.documentMessage?.caption ||
      msg.message?.liveLocationMessage?.caption ||
      msg.message?.listResponseMessage?.title ||
      msg.message?.buttonsResponseMessage?.selectedButtonId ||
      msg.message?.templateButtonReplyMessage?.selectedId ||
      msg.message?.productMessage?.product?.title ||
      msg.message?.orderMessage?.itemCount?.toString() ||
      ""
    ).trim();
    console.log(`Pesan dari ${from}: ${body}`);

    // ====== Perintah: Test Bot ======
    if (body.toLowerCase() === "ping") {
      await sock.sendMessage(from, {
        text: "✅ *[HamsBotz 002]* Test berhasil...",
      });
      return;
    }

    // ====== Perintah: Start Looping ======
    if (body.toLowerCase() === "!start") {
      if (!isAuthor) {
        return await sock.sendMessage(
          from,
          { text: "🚨 Kamu bukan admin" },
          { quoted: msg }
        );
      }

      await sock.sendMessage(
        from,
        {
          text: "✅ *[HamsBotz 002]* Memulai operasi...",
        },
        { quoted: msg }
      );

      await sock.sendMessage(HYDRO_JID, { text: "Hi" });
      return;
    }

    // ====== Perintah: Maintenance Group ======
    if (body === ".gc close") {
      if (!isAuthor) {
        return await sock.sendMessage(
          from,
          { text: "🚨 Kamu bukan admin" },
          { quoted: msg }
        );
      }

      await sock.groupSettingUpdate(from, "announcement");
      await sock.sendMessage(
        from,
        {
          text: "Group sedang Maintenance, jika ada pesan apapun dari bot, Mohon diabaikan terlebih dahulu",
        },
        { quoted: msg }
      );
    }

    // ====== Perintah: Maintenance Group ======
    if (body === ".gc open") {
      if (!isAuthor) {
        return await sock.sendMessage(
          from,
          { text: "🚨 Kamu bukan admin" },
          { quoted: msg }
        );
      }

      await sock.groupSettingUpdate(from, "not_announcement");
      await sock.sendMessage(
        from,
        { text: "Maintenance berakhir!! Terima kasih telah berbaik hati" },
        { quoted: msg }
      );
    }

    if (body.startsWith('!hidetag')) {
  const metadata = await sock.groupMetadata(from);
  const participants = metadata.participants;

  const adminList = participants
    .filter(p => p.admin === 'admin' || p.admin === 'superadmin')
    .map(p => p.id);

  const sender = msg.key.participant || msg.key.remoteJid;
  const isAdmin = adminList.includes(sender);

  if (!isAdmin) {
    await sock.sendMessage(from, {
      text: '🚫 Maaf, fitur ini hanya untuk admin grup.',
    }, { quoted: msg });
    return;
  }

  // 🧩 Ambil teks dari quoted / body / fallback
  let teks;

  // 1️⃣ Kalau ada quoted message
  if (msg.message.extendedTextMessage?.contextInfo?.quotedMessage) {
    const quoted =
      msg.message.extendedTextMessage.contextInfo.quotedMessage;
    teks =
      quoted.conversation ||
      quoted.extendedTextMessage?.text ||
      quoted.imageMessage?.caption ||
      quoted.videoMessage?.caption ||
      '👀';
  }
  // 2️⃣ Kalau tidak ada quoted → ambil dari teks setelah perintah
  else if (body.split(' ').slice(1).join(' ').trim()) {
    teks = body.split(' ').slice(1).join(' ').trim();
  }
  // 3️⃣ Kalau semua kosong → fallback ke emot default
  else {
    teks = '👀';
  }

  const allJid = participants.map(p => p.id);

  await sock.sendMessage(from, {
    text: teks,
    mentions: allJid,
  });
}

    
    // ====== Handler Otomatis Lain ======
    await handleAuto(
      sock,
      msg,
      from,
      OWNER_JID,
      TARGET_JID,
      TARGET_JID_VIP,
      TARGET_NEW
    );

    // ====== Perintah: VIP Rules ======
    await vipRules(sock, msg, body, from, OWNER_LID);
  });
}

// ====== Handle Exit Process ======
process.on("SIGINT", () => {
  logger.info("Shutting down...");
  process.exit(0);
});

module.exports = { connect };